<footer class="footer">
    <div class="d-sm-flex justify-content-center justify-content-sm-between">
        <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">
            Copyright © <span id="currentYear"></span>
            made with <i class="fa fa-heart"></i> by
            <a href="https://e-iuran.kanpa.co.id/" class="font-weight-bold" target="_blank">E-iuran (Beta Vers)</a>
            . All rights reserved.
        </span>
        <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">
            <a href="https://kanpa.co.id/" class="font-weight-bold" target="_blank">Supported by Kanpa.co.id</a>
        </span>
    </div>
</footer>


</div>
<!-- main-panel ends -->
</div>
<!-- page-body-wrapper ends -->
</div>
<!-- container-scroller -->