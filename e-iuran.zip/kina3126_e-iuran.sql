-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 27 Jul 2023 pada 04.27
-- Versi server: 10.1.31-MariaDB
-- Versi PHP: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kina3126_e-iuran`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(256) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `role` varchar(20) NOT NULL,
  `id_rtrw` int(11) NOT NULL,
  `id_perum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `nama`, `email`, `foto`, `role`, `id_rtrw`, `id_perum`) VALUES
(1, 'Admin', '21232f297a57a5a743894a0e4a801fc3', 'Kanpa', 'test@kanpa.co.id', 'default.png', 'Admin', 0, 0),
(2, 'admin06', '21232f297a57a5a743894a0e4a801fc3', 'Admin RT 06', 'admin@gmail.com', 'default.png', 'RT', 1, 1),
(3, 'admin07', '21232f297a57a5a743894a0e4a801fc3', 'Admin RT 07', 'admin@kanpa.com', 'default.png', 'RT', 3, 2),
(4, 'admin05', '21232f297a57a5a743894a0e4a801fc3', 'Admin RT 05', 'admin@gmail.com', 'default.png', 'RT', 2, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `iuran`
--

CREATE TABLE `iuran` (
  `id_iuran` int(11) NOT NULL,
  `id_rtrw` int(11) NOT NULL,
  `nama_iuran` varchar(100) NOT NULL,
  `nominal` int(11) NOT NULL,
  `perawatan` int(11) NOT NULL,
  `abunament` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `iuran`
--

INSERT INTO `iuran` (`id_iuran`, `id_rtrw`, `nama_iuran`, `nominal`, `perawatan`, `abunament`) VALUES
(1, 1, 'Iuran Sampah', 100000, 0, 0),
(2, 3, 'Tes iuran', 100000, 0, 0),
(3, 1, 'Iuran Air', 3000, 5000, 10000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `nama_iuran`
--

CREATE TABLE `nama_iuran` (
  `id` int(11) NOT NULL,
  `nama` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `perumahan`
--

CREATE TABLE `perumahan` (
  `id_perumahan` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `perumahan`
--

INSERT INTO `perumahan` (`id_perumahan`, `nama`) VALUES
(1, 'Bukit Permai 1'),
(2, 'Bukit Permai 2');

-- --------------------------------------------------------

--
-- Struktur dari tabel `rt-rw`
--

CREATE TABLE `rt-rw` (
  `id_rtrw` int(11) NOT NULL,
  `id_perum` int(11) NOT NULL,
  `rw` varchar(5) NOT NULL,
  `rt` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `rt-rw`
--

INSERT INTO `rt-rw` (`id_rtrw`, `id_perum`, `rw`, `rt`) VALUES
(1, 1, '02', '06'),
(2, 1, '02', '05'),
(3, 2, '03', '07');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tagihan`
--

CREATE TABLE `tagihan` (
  `id_tagihan` int(11) NOT NULL,
  `id_warga` int(11) NOT NULL,
  `id_iuran` int(11) NOT NULL,
  `no_invoice` varchar(20) NOT NULL,
  `bln_tagihan` varchar(13) NOT NULL,
  `thn_tagihan` varchar(13) NOT NULL,
  `kubik1` int(11) NOT NULL,
  `kubik_in` int(11) NOT NULL,
  `hasil_kubik` int(11) NOT NULL,
  `nominal` int(11) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tagihan`
--

INSERT INTO `tagihan` (`id_tagihan`, `id_warga`, `id_iuran`, `no_invoice`, `bln_tagihan`, `thn_tagihan`, `kubik1`, `kubik_in`, `hasil_kubik`, `nominal`, `status`) VALUES
(1, 1, 3, 'IV-072023-00001', 'Juli', '2023', 230, 320, 90, 270000, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` int(11) NOT NULL,
  `id_rtrw` int(11) NOT NULL,
  `id_warga` int(11) NOT NULL,
  `id_tagihan` int(11) NOT NULL,
  `tgl_upload` varchar(15) NOT NULL,
  `jumlah` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `warga`
--

CREATE TABLE `warga` (
  `id_warga` int(11) NOT NULL,
  `id_perum` int(11) NOT NULL,
  `id_rtrw` int(11) NOT NULL,
  `no_rumah` varchar(13) NOT NULL,
  `nama` varchar(150) NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `keterangan` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `warga`
--

INSERT INTO `warga` (`id_warga`, `id_perum`, `id_rtrw`, `no_rumah`, `nama`, `no_hp`, `keterangan`) VALUES
(1, 1, 1, 'A3', 'Pak Tyo', '081568491815', 'Inventaris'),
(2, 1, 1, 'A4', 'Natangel', '081226414648', 'Di Huni'),
(3, 1, 1, 'A5', 'Pak Ponco', '081914403443', 'Di Huni'),
(4, 1, 1, 'A6', 'Pak Rio', '089629781130', 'Inventaris'),
(5, 1, 1, 'A7', 'Bu Rosma', '081226032251', 'Di Huni'),
(6, 1, 1, 'A8', 'Habib', '081225384746', 'Di Huni'),
(7, 1, 1, 'A9', 'Ahmad Sukoco', '081226335774', 'Di Huni'),
(8, 1, 1, 'A10', 'Mas Budi', '082135159325', 'Di Huni'),
(9, 1, 1, 'A11', 'Rizki Apriyanto', '085100992979', 'Di Huni'),
(10, 1, 1, 'A12', 'Meila', '082144474886', 'Di Huni'),
(11, 1, 1, 'A13', '', '', 'Di Huni'),
(12, 1, 1, 'A14', '', '', 'Di Huni'),
(13, 1, 1, 'A15', '', '', 'Di Huni'),
(14, 1, 1, 'A16', '', '', 'Di Huni'),
(15, 1, 1, 'A17', '', '', ''),
(16, 1, 1, 'A18', '', '', ''),
(17, 1, 1, 'A19', '', '', 'Di Huni'),
(18, 1, 1, 'A20', '', '', ''),
(19, 1, 1, 'A21', '', '', 'Inventaris'),
(20, 1, 1, 'A22', '', '', 'Di Huni'),
(21, 1, 1, 'A23', '', '', 'Inventaris'),
(22, 1, 1, 'A24', '', '', ''),
(23, 1, 1, 'A25', '', '', 'Di Huni'),
(24, 1, 1, 'A26', '', '', 'Di Huni'),
(25, 1, 1, 'A27', '', '', 'Di Huni'),
(26, 1, 1, 'A28', '', '', 'Inventaris'),
(27, 1, 1, 'A29', '', '', 'Di Huni'),
(28, 1, 1, 'A30', '', '', 'Di Huni'),
(29, 1, 1, 'A31', '', '', 'Di Huni'),
(30, 1, 1, 'A32', '', '', 'Di Huni'),
(31, 2, 3, 'Tes222', 'Agus Supriyanto', '089615139363', 'Di Huni'),
(32, 1, 2, 'Tes 123', 'Okta', '0988998876', 'Inventaris'),
(34, 2, 3, 'A43', 'Hyuna', '089998989897', 'Di Huni');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `iuran`
--
ALTER TABLE `iuran`
  ADD PRIMARY KEY (`id_iuran`);

--
-- Indeks untuk tabel `nama_iuran`
--
ALTER TABLE `nama_iuran`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `perumahan`
--
ALTER TABLE `perumahan`
  ADD PRIMARY KEY (`id_perumahan`);

--
-- Indeks untuk tabel `rt-rw`
--
ALTER TABLE `rt-rw`
  ADD PRIMARY KEY (`id_rtrw`);

--
-- Indeks untuk tabel `tagihan`
--
ALTER TABLE `tagihan`
  ADD PRIMARY KEY (`id_tagihan`);

--
-- Indeks untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`);

--
-- Indeks untuk tabel `warga`
--
ALTER TABLE `warga`
  ADD PRIMARY KEY (`id_warga`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `iuran`
--
ALTER TABLE `iuran`
  MODIFY `id_iuran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `nama_iuran`
--
ALTER TABLE `nama_iuran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `perumahan`
--
ALTER TABLE `perumahan`
  MODIFY `id_perumahan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `rt-rw`
--
ALTER TABLE `rt-rw`
  MODIFY `id_rtrw` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `tagihan`
--
ALTER TABLE `tagihan`
  MODIFY `id_tagihan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `warga`
--
ALTER TABLE `warga`
  MODIFY `id_warga` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
