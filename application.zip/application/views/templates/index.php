<?php $this->load->view('templates/header'); ?>
<?php $this->load->view('templates/navbar'); ?>
<?php $this->load->view('templates/sidebar'); ?>
<?php $this->load->view($content); ?>
<?php $this->load->view('templates/footer'); ?>
<?php $this->load->view('templates/footer_js'); ?>